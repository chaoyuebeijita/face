# faceRecognition
利用OpenCV、CNN进行人脸识别
万壑，497899960@qq.com
