import numpy as np 
import cv2
import sys
import time
import os
def CatVideo():
	cv2.namedWindow("shibie")
	#1调用摄像头
	cap=cv2.VideoCapture(0)
	#2人脸识别器分类器
	classfier=cv2.CascadeClassifier("Train.xml")
	color=(0,255,0)
	while cap.isOpened():
		ok,frame=cap.read()
		if not ok:
			break
		#2灰度转换
		grey=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
		#人脸检测，1.2和2分别为图片缩放比例和需要检测的有效点数
		faceRects = classfier.detectMultiScale(grey, scaleFactor = 1.2, minNeighbors = 3, minSize = (32, 32))
		if len(faceRects) > 0:            #大于0则检测到人脸                                
			for  (x, y, w, h) in faceRects :
				listStr = [str(int(time.time())), str(0)]  #以时间戳和读取的排序作为文件名称
				fileName = ''.join(listStr)

				f = cv2.resize(grey[y:(y + h), x:(x + w)], (98, 116))
				cv2.imwrite('D:\opencv\pictures\picTest'+os.sep+'%s.jpg' % fileName, f)   
				cv2.rectangle(frame, (x - 10, y - 10), (x + w + 10, y + h + 10), color, 3)
		cv2.imshow("shibie",frame)
		print("ceshi2")
		if cv2.waitKey(10)&0xFF==ord('q'):
			break

	cap.release()
	cv2.destroyAllWindows()



CatVideo()