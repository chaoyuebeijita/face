from numpy import *
from numpy import linalg as la
import cv2
import os
import math
from read_data import read_name_list


os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

# 为了让LBP具有旋转不变性，将二进制串进行旋转。
# 假设一开始得到的LBP特征为10010000，那么将这个二进制特征，
# 按照顺时针方向旋转，可以转化为00001001的形式，这样得到的LBP值是最小的。
# 无论图像怎么旋转，对点提取的二进制特征的最小值是不变的，
# 用最小值作为提取的LBP特征，这样LBP就是旋转不变的了。
def minBinary(pixel):
    length = len(pixel)
    zero = ''
    for i in range(length)[::-1]:
        if pixel[i] == '0':
            pixel = pixel[:i]
            zero += '0'
        else:
            return zero + pixel
    if len(pixel) == 0:
        return '0'

# 加载图像
def loadImageSet(add):  #add是路径
    print("步骤1")
    FaceMat = mat(zeros((1,98*116)))#根据图片尺寸更改   一共有几行
    j =0
    for i in os.listdir(add):
        #print(i)  #图片正常显示了
        #print(i.split('.')[1])  输出结果：jpg
        if i.split('.')[1] == 'jpg':
            try:
                img = cv2.imread(add+i,0)
                #print(add+i)   输出结果：D:\opencv\huge/15138183801.jpg
                # cv2.imwrite(str(i)+'.jpg',img)
            except:
                print ('load %s failed'%i)
            FaceMat[j,:] = mat(img).flatten()
            #print(FaceMat[j,:])   #取第j行
            #print(FaceMat[:,j])   #取第j列
            #http://blog.csdn.net/qq_18433441/article/details/54916991  flatten详解
            j += 1
    #print(FaceMat)
    return FaceMat

# 算法主过程
def LBP(FaceMat,R = 2,P = 8):
    print("步骤2")
    Region8_x=[-1,0,1,1,1,0,-1,-1]
    Region8_y=[-1,-1,-1,0,1,1,1,0]
    pi = math.pi
    LBPoperator = mat(zeros(shape(FaceMat)))
    for i in range(shape(FaceMat)[1]):
        # 对每一个图像进行处理  转化成116*98的二维矩阵
        face = FaceMat[:,i].reshape(116,98)

        W,H = shape(face)
        tempface = mat(zeros((W,H)))
        for x in range(R,W-R):
            for y in range(R,H-R):
                repixel = ''
                pixel=int(face[x,y]) #取每一个值
                #　圆形LBP算子
                for p in [2,1,0,7,6,5,4,3]:
                    p = float(p)
                    xp = x + R* cos(2*pi*(p/P))
                    yp = y - R* sin(2*pi*(p/P))
                    #print(xp)  输出结果 2.0
                    #print(pixel)  输出结果 1
                    #print(yp)   0.0
                    #print(face[2,0])  1.0
                    if int(face[int(xp),int(yp)])>pixel:
                        repixel += '1'
                    else:
                        repixel += '0'
                # minBinary保持LBP算子旋转不变
                tempface[x,y] = int(minBinary(repixel),base=2)
        LBPoperator[:,i] = tempface.flatten().T
        # cv2.imwrite(str(i)+'hh.jpg',array(tempface,uint8))
    return LBPoperator

    # judgeImg:未知判断图像
    # LBPoperator:实验图像的LBP算子
    # exHistograms:实验图像的直方图分布
def judgeFace(judgeImg,LBPoperator,exHistograms):
    judgeImg = judgeImg.T
    ImgLBPope = LBP(judgeImg)
    #  把图片分为7*4份 , calHistogram返回的直方图矩阵有28个小矩阵内的直方图
    judgeHistogram = calHistogram(ImgLBPope)
    minIndex = 0
    minVals = inf    #正无穷


    for  i in range(shape(LBPoperator)[1]):
        exHistogram = exHistograms[:,i]
        diff = (array(exHistogram-judgeHistogram)**2).sum()
        print(diff)
    return diff

# 统计直方图
def calHistogram(ImgLBPope):
    Img = ImgLBPope.reshape(116,98)
    W,H = shape(Img)
    # 把图片分为7*4份
    Histogram = mat(zeros((256,7*4)))
    maskx,masky = W/4,H/7  #29 14
    for i in range(4):
        for j in range(7):
            # 使用掩膜opencv来获得子矩阵直方图
            mask = zeros(shape(Img), uint8)
            mask[int(i*maskx): int((i+1)*maskx),int(j*masky) :int((j+1)*masky)] = 255
            hist = cv2.calcHist([array(Img,uint8)],[0],mask,[ 256],[0,256])
            Histogram[:,(i+1)*(j+1)-1] = mat(hist).flatten().T
    return Histogram.flatten().T

def runLBP(tuPianPath):
    # 加载图像
    FaceMat = loadImageSet(tuPianPath).T  #反转矩阵
    LBPoperator = LBP(FaceMat) # 获得实验图像LBP算子
    
    # 获得实验图像的直方图分布，这里计算是为了可以多次使用
    exHistograms = mat(zeros((256*4*7,shape(LBPoperator)[1])))
    for i in range(shape(LBPoperator)[1]):
        exHistogram = calHistogram(LBPoperator[:,i])
        exHistograms[:,i] = exHistogram
    allLBPoperator.append(LBPoperator)
    allexHistograms.append(exHistograms)
    #build_camera(LBPoperator,exHistograms)
    #loadname = 'D:\opencv/'+'8.jpg'
    #judgeImg = cv2.imread(loadname,0)
    #jresult=judgeFace(mat(judgeImg).flatten(),LBPoperator,exHistograms)
    #if judgeFace(mat(judgeImg).flatten(),LBPoperator,exHistograms)+1 == int(nameList[i]):
    
def build_camera():
    print(1111)
    #opencv文件中人脸级联文件的位置，用于帮助识别图像或者视频流中的人脸
    face_cascade = cv2.CascadeClassifier('Train.xml')

    #打开摄像头并开始读取画面
    cameraCapture = cv2.VideoCapture(0)
    success, frame = cameraCapture.read()

    while success and cv2.waitKey(1) == -1:
        success, frame = cameraCapture.read()
        grey = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) #图像灰化
        faces = face_cascade.detectMultiScale(grey, 1.3, 5) #识别人脸
        for (x, y, w, h) in faces:
            f = cv2.resize(grey[y:(y + h), x:(x + w)], (98, 116))
            result=inf
            show_name=''
            for i in range(len(allTuPianPath)):
                jresult=judgeFace(mat(f).flatten(),allLBPoperator[i],allexHistograms[i])
                if jresult==0:
                    show_name=allmen[i]
                    break
                elif jresult<result:
                    result=jresult
                    show_name=allmen[i]
            #print(f)
            # if prob >0.5:    #如果模型认为概率高于70%则显示为模型中已有的label
            #     show_name = name_list[label]
            # else:
            #     show_name = 'Stranger'
            cv2.putText(frame, show_name, (x, y - 20), cv2.FONT_HERSHEY_SIMPLEX, 1, 255, 2)  #显示名字
            frame = cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)  #在人脸区域画一个正方形出来
        cv2.imshow("Camera", frame)
    return show_name


    cameraCapture.release()
    cv2.destroyAllWindows()



if __name__ == '__main__':
    allLBPoperator=[]
    allexHistograms=[]
    allTuPianPath=['D:\opencv\photoKu\huge/','D:\opencv\photoKu\luyi/','D:\opencv\photoKu\me/','D:\opencv\photoKu\shayi/','D:\opencv\photoKu\wuyanzu/','D:\opencv\photoKu\zhoujielun/']
    allmen=['hege','luyi','me','shayi','wuyanzu','zhoujielun']
    for tuPianPath in allTuPianPath:
        runLBP(tuPianPath)
    name=build_camera()
    print(name)

    